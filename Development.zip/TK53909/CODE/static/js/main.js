(function() {
    
    $.fatNav();
    
}());